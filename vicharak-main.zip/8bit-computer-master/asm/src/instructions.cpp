#include "instructions.h"

const std::unordered_map<Instruction, std::string> instructionMap = {
    {Instruction::NOP, "nop"},
    {Instruction::CALL, "call"},
    {Instruction::RET, "ret"},
    {Instruction::LDA, "lda"},
    {Instruction::STA, "sta"},
    {Instruction::IN, "in"},
    {Instruction::OUT, "out"},
    {Instruction::HLT, "hlt"},
    {Instruction::CMP, "cmp"},
    {Instruction::JMP, "jmp"},
    {Instruction::JZ, "jz"},
    {Instruction::JNZ, "jnz"},
    {Instruction::JE, "je"},
    {Instruction::JNE, "jne"},
    {Instruction::JC, "jc"},
    {Instruction::JNC, "jnc"},
    {Instruction::PUSH, "push"},
    {Instruction::POP, "pop"},
    {Instruction::ADD, "add"},
    {Instruction::SUB, "sub"},
    {Instruction::INC, "inc"},
    {Instruction::DEC, "dec"},
    {Instruction::AND, "and"},
    {Instruction::OR, "or"},
    {Instruction::XOR, "xor"},
    {Instruction::ADC, "adc"},
    {Instruction::LDI, "ldi"},
    {Instruction::MOV, "mov"},
};

std::string getAssemblyInstruction(Instruction op){
    auto it = instructionMap.find(op);
    if(it != instructionMap.end()){
        return it->second;
    }

    return "";
}