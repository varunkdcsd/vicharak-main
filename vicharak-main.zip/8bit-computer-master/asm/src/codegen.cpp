#include "codegen.h"

std :: string CodeGenerator::generate(ASTNode* root){
    std::string assembly;

    for(auto child : root -> children){
        if(child -> type == AST_NODE_ASSIGN){
            assembly += "mov" + child -> children[0] -> value + ", " + child->children[1]->value + "\n";
        }
    }

    return assembly;
}