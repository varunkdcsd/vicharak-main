#include "lexer.h"
#include <cctype>
#include <stdexcept>

Lexer::Lexer(const std::string &source) : source(source), pos(0) {}

std::vector<Token> Lexer::tokenize(){
    std :: vector<Token> tokens;

    while(pos < source.size()){
        char current = source[pos];

        if(isspace(current)){
            pos++;
            continue;
        }

        if(isalpha(current)){
            std::string identifier;
            while(isalnum(current)){
                identifier += current;
                current = source[++pos];
            }
            tokens.push_back({TOKEN_IDENTIFIER, identifier});
            continue;
        }

        if(isdigit(current)){
            std::string number;
            
            while(isdigit(current)){
                number += current;
                current = source[++pos];
            }
            tokens.push_back({TOKEN_NUMBER, number});
            continue;
        }

        switch(current){
            case '=':
                tokens.push_back({TOKEN_ASSIGN, '='});
                pos++;
                break;

            case '+':
            tokens.push_back({TOKEN_PLUS, '+'});
            pos++;
            break;

            case '-':
            tokens.push_back({TOKEN_MINUS, '-'});
            pos++;
            break;

            case '{':
            tokens.push_back({TOKEN_LBRACE, '{'});
            pos++;
            break;

            case '}':
                tokens.push_back({TOKEN_RBRACE, '}'});
                pos++;
                break;
            case ';':
                tokens.push_back({TOKEN_SEMICOLON, ';'});
                pos++;
                break;

            default:
            tokens.push_back({TOKEN_UNKNOWN, std::string(1, current)})
            pos++;
            break;
        }
    }

    tokens.push_back({TOKEN_EOF, ""});
    return tokens;
}