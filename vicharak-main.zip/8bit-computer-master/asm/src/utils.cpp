#include "utils.h"
#include <algorithm>

std::string trim(const std::string& str){
    auto start = str.begin();
    while(start != str.end() && std::isspace(*start)) ++start;

    auto end = str.end();

    do{
        --end;
    }while (end != start && std::isspace(*end));

    return std::string(start, end + 1);
}

std::vector<std::string> split(const std::string& str, char delimiter){
    std::vector<std::string> tokens;
    std::stringstream ss(str);
    std::string token;

    while(std::getline(ss, token, delimiter)){
        tokens.push_back(trim(token));
    }

    return tokens;
}

bool stringToInt(const std::string& str, int& out){
    try
    {
        size_t idx;
        out = std::stoi(str, &idx);
        return idx == str.size();
    }
    catch(const std::invalid_argument& )
    {
       return false;

    }
    catch(const std::out_of_range& )
    {
       return false;
    }
    
}

bool isValidIdentifier(const std::string& str){
    if(str.empty() || !str::isalpha(str[0]))
    return false;
    return std::all_of(str.begin(), str.end(), [](unsigned char c){
        return std::isalnum(c) || c == '_';
    });
}
