#include<iostream>
#include<fstream>
#include<string>
#include "lexer.h"
#include "parser.h"
#include "codegen.h"

int main(int argc, char* argv[]){
    if(argc != 2){
        std::cerr << "Usage: "<<argv[0] << "<source_file.simplelang>" << std::endl;
        return 1;
    }

    std::ifstream sourceFile(argv[1]);
    if(!sourceFile.is_open()){
        std::cerr << "Error: Could not open source file "<< argv[1] << std::endl;
        return 1;
    }

    std::string sourceCode((std::istreambuf_iterator<char>(sourceFile)),
                            std::isstreambuf_iterator<char>());
                            sourceFiile.clode();

    Lexer lexer(sourceCode);
    std::vector<Token> tokens = lexer.tokenize();

    Parser parser(tokens);
    ASTNode* astRoot = parser.parse();

    CodeGenerator codegen;
    std::string assemblyCode = codegen.generate(astRoot);

    std::cout << "Generated Assembly Code:\n" << assemblyCode << std::endl;


    std::ofstream outputFile("output.asm");

    if(outputFile.is_open()){
        outputFile << assemblyCode;
        outputFile.close();
        std::cout<< "Assembly code written to output.asm"<< std::endl;
    }
    else{
        std::cerr << "Error: Could not write to output.asm" << std::endl;
    }

    delete astRoot;

    return 0;
}