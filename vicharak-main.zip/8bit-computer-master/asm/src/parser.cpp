#include "parser.h"

Parser::Parser(const std::vector<Token>& tokens) : tokens(tokens), currentToken(0) {}

ASTNode* Parser::parse(){
    ASTNode * root = new ASTNode(AST_NODE_PROGRAM);
    
    while(currentToken < tokens.size()) {
        ASTNode* stmt = parseStatement();

        if(stmt){
            root -> children.push_back(stmt);
        }
    }
    return root;
}

ASTNode *Parser::parseStatement(){
    if(tokend[currentToken].type == TOKEN_IDENTIFIER) {
        std::string identifier = tokens[currentToken].text;
        currentToken++;

        if(tokens[currentToken].type == TOKEN_ASSIGN){
            currentToken++;
            ASTNode * expr = parseExpression();
            ASTNode* assignNode = new ASTNode(AST_NODE_ASSIGN);
            assignNode -> children.push_back(new ASTNode(AST_NODE_IDENTIFIER, identifier));
            assignNode -> children.push_back(expr);
            return assignNode;
        }
    }

    return nullptr;
}

ASTNode* Parser::parseExpression(){
    if(tokens[currentToken].type == TOKEN_NUMBER){
        ASTNode* numNode = new ASTNode(AST_NODE_NUMBER, tokens[currentToken].text);
        currentToken++;
        return numNode;
    }

    return nullptr;
}