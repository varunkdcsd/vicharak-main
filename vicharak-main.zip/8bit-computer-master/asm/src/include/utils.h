#ifndef UTILS_H
#define UTILS_H

#include <string>

std::string trim(const std::string& str);

std::vector<std::string> split(const std::string& str, char delimiter);

bool stringToInt(const std::string& str, int& out);

bool isValidIdentifier(const std::string& str);

#endif