#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

#include <string>
#include <unordered_map>

enum  Instruction {
    NOP,
    MOV,
    ADD,
    SUB,
    CALL,
    RET,
    LDA,
    OUT,
    IN, 
    HLT, 
    CMP,
    STA,
    JMP,
    JZ,
    JNC,
    JE,
    JNE,
    JC,
    JNC,
    PUSH,
    POP,
    INC, 
    DEC,
    AND,
    OR,
    XOR,
    ADC,
    LDI
};

extern const std::unordered_map<Instruction, std::string> instructionMap;

std::string getAssemblyInstruction(Instruction op);

struct InstructionSet{
    Instruction operation;
    std::string assemblyCode;
}



#endif