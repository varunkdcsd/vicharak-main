#ifndef CODEGEN_H
#define CODEGEN_H

#include "ast.h"
#include <string>

class CodeGenerator {
    public: 
    std :: string generate(ASTNode* root);
};

#endif