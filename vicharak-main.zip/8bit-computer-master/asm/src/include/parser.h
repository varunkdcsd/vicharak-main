#ifndef PARSER_H
#define PARSER_H

#include <vector>
#include "lexer.h"
#include "ast.h"

class Parser{
    public:
    Parser(const std::vector<Token>& tokens);
    ASTNode * parse();

    private:
    std::vector<Token> tokens;
    size_t currentToken;
    ASTNode * parseStatement();
    ASTNode * parseExpression();
};

#endif