#ifndef AST_H
#define AST_H

#include <vector>
#include <string>

enum ASTNodeType {
    AST_NODE_PROGRAM,
    AST_NODE_ASSIGN,
    AST_NODE_IDENTIFIER,
    AST_NODE_NUMBER
};

struct ASTNode{
    ASTNodeType type;
    std::string value;
    std::vector<ASTNode*> children;

    ASTNode(ASTNodeType type, const std::string &value = "")
    : type(type), value(value) {}

    ~ASTNode(){
        for(auto child : children){
            delete child;
        }
    }
};

#endif